<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LicenseWebLink extends Model
{
    protected $guarded = [];
}
