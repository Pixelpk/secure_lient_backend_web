<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemTax extends Model
{
    protected $guarded = [];
}
