<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContractForm extends Model
{
    protected $guarded = [];
}
