<!DOCTYPE html>
<html>
<head>
    <title>Lies Contract Form</title>
</head>
<body>
    <h1>Lies Contract Form</h1>
    <p>Please fill out all the details and again sent email to us for further process.</p><br/>
    <p>{{ date("Y-m-d") }}</p>
     
    <p>Thank you</p>
</body>
</html>